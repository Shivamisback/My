# Animated Login Form
## [Watch it on youtube](https://youtu.be/b7gc_4TrXkg)
### Animated Login Form

- Animated Login Form Using HTML CSS & JavaScript
- It contains a stylish and beautiful background.
- With animation of floating labels.
- And a button to show and hide the password.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/@Bedimcode)

![preview img](/preview.png)
